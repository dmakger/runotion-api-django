from django.urls import path, include
from rest_framework.routers import DefaultRouter

from project.views.project import ProjectView, ProjectUpdateAPIView, ProjectDeleteAPIView, RoleProjectListAPIView, \
    ProjectUserListAPIView
from project.views.section import SectionProjectListView, SectionProjectDeleteAPIView, SectionProjectUpdateAPIView, \
    SectionProjectCreateAPIView

router = DefaultRouter()

urlpatterns = [
    path('', include(router.urls)),

    #  Проекты
    path("all/", ProjectView.as_view({'get': 'get_projects'})),
    path("detail/<int:pk>/", ProjectView.as_view({'get': 'get_project_by_id'})),
    path("create/", ProjectView.as_view({'post': 'create_project'})),
    path("<int:pk>/update/", ProjectUpdateAPIView.as_view()),
    path("<int:pk>/delete/", ProjectDeleteAPIView.as_view()),
    path("roles/", RoleProjectListAPIView.as_view()),
    path("<int:project_pk>/users/", ProjectUserListAPIView.as_view()),
    path("<int:project_pk>/users/<int:user_pk>/", ProjectUserListAPIView.as_view()),

    #  Секции по проектам
    path("<int:project_pk>/section/all/", SectionProjectListView.as_view()),
    path("<int:project_pk>/section/create/", SectionProjectCreateAPIView.as_view()),
    path("<int:project_pk>/section/<int:pk>/update/", SectionProjectUpdateAPIView.as_view()),
    path("<int:project_pk>/section/<int:pk>/delete/", SectionProjectDeleteAPIView.as_view()),
]
